gdjs.lettersCode = {};
gdjs.lettersCode.forEachIndex3 = 0;

gdjs.lettersCode.forEachObjects3 = [];

gdjs.lettersCode.forEachTemporary3 = null;

gdjs.lettersCode.forEachTotalCount3 = 0;

gdjs.lettersCode.repeatCount3 = 0;

gdjs.lettersCode.repeatCount4 = 0;

gdjs.lettersCode.repeatIndex3 = 0;

gdjs.lettersCode.repeatIndex4 = 0;

gdjs.lettersCode.GDbgObjects1= [];
gdjs.lettersCode.GDbgObjects2= [];
gdjs.lettersCode.GDbgObjects3= [];
gdjs.lettersCode.GDbgObjects4= [];
gdjs.lettersCode.GDbgObjects5= [];
gdjs.lettersCode.GDbgObjects6= [];
gdjs.lettersCode.GDlettersLenObjects1= [];
gdjs.lettersCode.GDlettersLenObjects2= [];
gdjs.lettersCode.GDlettersLenObjects3= [];
gdjs.lettersCode.GDlettersLenObjects4= [];
gdjs.lettersCode.GDlettersLenObjects5= [];
gdjs.lettersCode.GDlettersLenObjects6= [];
gdjs.lettersCode.GDlettersSenObjects1= [];
gdjs.lettersCode.GDlettersSenObjects2= [];
gdjs.lettersCode.GDlettersSenObjects3= [];
gdjs.lettersCode.GDlettersSenObjects4= [];
gdjs.lettersCode.GDlettersSenObjects5= [];
gdjs.lettersCode.GDlettersSenObjects6= [];
gdjs.lettersCode.GDlettersLgrObjects1= [];
gdjs.lettersCode.GDlettersLgrObjects2= [];
gdjs.lettersCode.GDlettersLgrObjects3= [];
gdjs.lettersCode.GDlettersLgrObjects4= [];
gdjs.lettersCode.GDlettersLgrObjects5= [];
gdjs.lettersCode.GDlettersLgrObjects6= [];
gdjs.lettersCode.GDlettersSgrObjects1= [];
gdjs.lettersCode.GDlettersSgrObjects2= [];
gdjs.lettersCode.GDlettersSgrObjects3= [];
gdjs.lettersCode.GDlettersSgrObjects4= [];
gdjs.lettersCode.GDlettersSgrObjects5= [];
gdjs.lettersCode.GDlettersSgrObjects6= [];
gdjs.lettersCode.GDdbgObjects1= [];
gdjs.lettersCode.GDdbgObjects2= [];
gdjs.lettersCode.GDdbgObjects3= [];
gdjs.lettersCode.GDdbgObjects4= [];
gdjs.lettersCode.GDdbgObjects5= [];
gdjs.lettersCode.GDdbgObjects6= [];
gdjs.lettersCode.GDenbObjects1= [];
gdjs.lettersCode.GDenbObjects2= [];
gdjs.lettersCode.GDenbObjects3= [];
gdjs.lettersCode.GDenbObjects4= [];
gdjs.lettersCode.GDenbObjects5= [];
gdjs.lettersCode.GDenbObjects6= [];
gdjs.lettersCode.GDgrbObjects1= [];
gdjs.lettersCode.GDgrbObjects2= [];
gdjs.lettersCode.GDgrbObjects3= [];
gdjs.lettersCode.GDgrbObjects4= [];
gdjs.lettersCode.GDgrbObjects5= [];
gdjs.lettersCode.GDgrbObjects6= [];
gdjs.lettersCode.GDerbObjects1= [];
gdjs.lettersCode.GDerbObjects2= [];
gdjs.lettersCode.GDerbObjects3= [];
gdjs.lettersCode.GDerbObjects4= [];
gdjs.lettersCode.GDerbObjects5= [];
gdjs.lettersCode.GDerbObjects6= [];

gdjs.lettersCode.conditionTrue_0 = {val:false};
gdjs.lettersCode.condition0IsTrue_0 = {val:false};
gdjs.lettersCode.condition1IsTrue_0 = {val:false};
gdjs.lettersCode.condition2IsTrue_0 = {val:false};
gdjs.lettersCode.condition3IsTrue_0 = {val:false};
gdjs.lettersCode.conditionTrue_1 = {val:false};
gdjs.lettersCode.condition0IsTrue_1 = {val:false};
gdjs.lettersCode.condition1IsTrue_1 = {val:false};
gdjs.lettersCode.condition2IsTrue_1 = {val:false};
gdjs.lettersCode.condition3IsTrue_1 = {val:false};


gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSenObjects5Objects = Hashtable.newFrom({"lettersSen": gdjs.lettersCode.GDlettersSenObjects5});gdjs.lettersCode.eventsList0x1caf78a0 = function(runtimeScene, context) {

{


{
/* Reuse gdjs.lettersCode.GDlettersSenObjects5 */
{for(var i = 0, len = gdjs.lettersCode.GDlettersSenObjects5.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersSenObjects5[i].setAnimation(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.lettersCode.GDlettersSenObjects5.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersSenObjects5[i].setPosition(50,60 + (80*gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))));
}
}}

}


}; //End of gdjs.lettersCode.eventsList0x1caf78a0
gdjs.lettersCode.eventsList0xe5cb2a8 = function(runtimeScene, context) {

{


{
gdjs.lettersCode.GDlettersSenObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSenObjects5Objects, 0, 0, "");
}
{ //Subevents
gdjs.lettersCode.eventsList0x1caf78a0(runtimeScene, context);} //End of subevents
}

}


{


{
{runtimeScene.getVariables().getFromIndex(0).add(1);
}}

}


}; //End of gdjs.lettersCode.eventsList0xe5cb2a8
gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSenObjects5Objects = Hashtable.newFrom({"lettersSen": gdjs.lettersCode.GDlettersSenObjects5});gdjs.lettersCode.eventsList0x1caf6b80 = function(runtimeScene, context) {

{


{
/* Reuse gdjs.lettersCode.GDlettersSenObjects5 */
{for(var i = 0, len = gdjs.lettersCode.GDlettersSenObjects5.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersSenObjects5[i].setAnimation(13 + gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.lettersCode.GDlettersSenObjects5.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersSenObjects5[i].setPosition(130,60 + (80*gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))));
}
}}

}


}; //End of gdjs.lettersCode.eventsList0x1caf6b80
gdjs.lettersCode.eventsList0xe5cb318 = function(runtimeScene, context) {

{


{
gdjs.lettersCode.GDlettersSenObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSenObjects5Objects, 0, 0, "");
}
{ //Subevents
gdjs.lettersCode.eventsList0x1caf6b80(runtimeScene, context);} //End of subevents
}

}


{


{
{runtimeScene.getVariables().getFromIndex(0).add(1);
}}

}


}; //End of gdjs.lettersCode.eventsList0xe5cb318
gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSenObjects2Objects = Hashtable.newFrom({"lettersSen": gdjs.lettersCode.GDlettersSenObjects2});gdjs.lettersCode.eventsList0x1caf7b40 = function(runtimeScene, context) {

{


{
{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}}

}


{


gdjs.lettersCode.repeatCount4 = 13;
for(gdjs.lettersCode.repeatIndex4 = 0;gdjs.lettersCode.repeatIndex4 < gdjs.lettersCode.repeatCount4;++gdjs.lettersCode.repeatIndex4) {

if (true)
{

{ //Subevents: 
gdjs.lettersCode.eventsList0xe5cb2a8(runtimeScene, context);} //Subevents end.
}
}

}


{


{
{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}}

}


{


gdjs.lettersCode.repeatCount4 = 13;
for(gdjs.lettersCode.repeatIndex4 = 0;gdjs.lettersCode.repeatIndex4 < gdjs.lettersCode.repeatCount4;++gdjs.lettersCode.repeatIndex4) {

if (true)
{

{ //Subevents: 
gdjs.lettersCode.eventsList0xe5cb318(runtimeScene, context);} //Subevents end.
}
}

}


{

gdjs.lettersCode.GDlettersSenObjects2.createFrom(runtimeScene.getObjects("lettersSen"));

gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickAllObjects(runtimeScene, gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSenObjects2Objects);
}if (gdjs.lettersCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lettersCode.GDlettersSenObjects2 */
{for(var i = 0, len = gdjs.lettersCode.GDlettersSenObjects2.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersSenObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.lettersCode.GDlettersSenObjects2.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersSenObjects2[i].setScale(0.75);
}
}}

}


}; //End of gdjs.lettersCode.eventsList0x1caf7b40
gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSgrObjects4Objects = Hashtable.newFrom({"lettersSgr": gdjs.lettersCode.GDlettersSgrObjects4});gdjs.lettersCode.eventsList0x1caf1f60 = function(runtimeScene, context) {

{


{
/* Reuse gdjs.lettersCode.GDlettersSgrObjects4 */
{for(var i = 0, len = gdjs.lettersCode.GDlettersSgrObjects4.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersSgrObjects4[i].setAnimation(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.lettersCode.GDlettersSgrObjects4.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersSgrObjects4[i].setPosition(50,60 + (80*gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))));
}
}}

}


}; //End of gdjs.lettersCode.eventsList0x1caf1f60
gdjs.lettersCode.eventsList0xe5cb238 = function(runtimeScene, context) {

{


{
gdjs.lettersCode.GDlettersSgrObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSgrObjects4Objects, 0, 0, "");
}
{ //Subevents
gdjs.lettersCode.eventsList0x1caf1f60(runtimeScene, context);} //End of subevents
}

}


{


{
{runtimeScene.getVariables().getFromIndex(0).add(1);
}}

}


}; //End of gdjs.lettersCode.eventsList0xe5cb238
gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSgrObjects4Objects = Hashtable.newFrom({"lettersSgr": gdjs.lettersCode.GDlettersSgrObjects4});gdjs.lettersCode.eventsList0x1caf2020 = function(runtimeScene, context) {

{


{
/* Reuse gdjs.lettersCode.GDlettersSgrObjects4 */
{for(var i = 0, len = gdjs.lettersCode.GDlettersSgrObjects4.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersSgrObjects4[i].setAnimation(12 + gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.lettersCode.GDlettersSgrObjects4.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersSgrObjects4[i].setPosition(130,60 + (80*gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))));
}
}}

}


}; //End of gdjs.lettersCode.eventsList0x1caf2020
gdjs.lettersCode.eventsList0xe5cb1c8 = function(runtimeScene, context) {

{


{
gdjs.lettersCode.GDlettersSgrObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSgrObjects4Objects, 0, 0, "");
}
{ //Subevents
gdjs.lettersCode.eventsList0x1caf2020(runtimeScene, context);} //End of subevents
}

}


{


{
{runtimeScene.getVariables().getFromIndex(0).add(1);
}}

}


}; //End of gdjs.lettersCode.eventsList0xe5cb1c8
gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSgrObjects1Objects = Hashtable.newFrom({"lettersSgr": gdjs.lettersCode.GDlettersSgrObjects1});gdjs.lettersCode.eventsList0x1caf2440 = function(runtimeScene, context) {

{


{
{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}}

}


{


gdjs.lettersCode.repeatCount3 = 12;
for(gdjs.lettersCode.repeatIndex3 = 0;gdjs.lettersCode.repeatIndex3 < gdjs.lettersCode.repeatCount3;++gdjs.lettersCode.repeatIndex3) {

if (true)
{

{ //Subevents: 
gdjs.lettersCode.eventsList0xe5cb238(runtimeScene, context);} //Subevents end.
}
}

}


{


{
{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}}

}


{


gdjs.lettersCode.repeatCount3 = 12;
for(gdjs.lettersCode.repeatIndex3 = 0;gdjs.lettersCode.repeatIndex3 < gdjs.lettersCode.repeatCount3;++gdjs.lettersCode.repeatIndex3) {

if (true)
{

{ //Subevents: 
gdjs.lettersCode.eventsList0xe5cb1c8(runtimeScene, context);} //Subevents end.
}
}

}


{

gdjs.lettersCode.GDlettersSgrObjects1.createFrom(runtimeScene.getObjects("lettersSgr"));

gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickAllObjects(runtimeScene, gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSgrObjects1Objects);
}if (gdjs.lettersCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lettersCode.GDlettersSgrObjects1 */
{for(var i = 0, len = gdjs.lettersCode.GDlettersSgrObjects1.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersSgrObjects1[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.lettersCode.GDlettersSgrObjects1.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersSgrObjects1[i].setScale(0.75);
}
}}

}


}; //End of gdjs.lettersCode.eventsList0x1caf2440
gdjs.lettersCode.eventsList0x1caf73c0 = function(runtimeScene, context) {

{


{
{runtimeScene.getVariables().getFromIndex(4).setNumber(0);
}}

}


{


gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 0;
}if (gdjs.lettersCode.condition0IsTrue_0.val) {
gdjs.lettersCode.GDdbgObjects2.createFrom(runtimeScene.getObjects("dbg"));
{for(var i = 0, len = gdjs.lettersCode.GDdbgObjects2.length ;i < len;++i) {
    gdjs.lettersCode.GDdbgObjects2[i].hide();
}
}}

}


{


gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "EN";
}if (gdjs.lettersCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf7b40(runtimeScene, context);} //End of subevents
}

}


{


gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "GR";
}if (gdjs.lettersCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf2440(runtimeScene, context);} //End of subevents
}

}


}; //End of gdjs.lettersCode.eventsList0x1caf73c0
gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersLenObjects2Objects = Hashtable.newFrom({"lettersLen": gdjs.lettersCode.GDlettersLenObjects2});gdjs.lettersCode.eventsList0x1caf7540 = function(runtimeScene, context) {

{


{
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("EN");
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "letters", false);
}}

}


}; //End of gdjs.lettersCode.eventsList0x1caf7540
gdjs.lettersCode.eventsList0x1caf6640 = function(runtimeScene, context) {

{


{
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("GR");
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "letters", false);
}}

}


}; //End of gdjs.lettersCode.eventsList0x1caf6640
gdjs.lettersCode.eventsList0x1caf7a20 = function(runtimeScene, context) {

{


{
gdjs.lettersCode.GDlettersLenObjects2.createFrom(runtimeScene.getObjects("lettersLen"));
{runtimeScene.getVariables().getFromIndex(3).setNumber(gdjs.evtTools.object.pickedObjectsCount(gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersLenObjects2Objects));
}}

}


{


{
gdjs.lettersCode.GDdbgObjects2.createFrom(runtimeScene.getObjects("dbg"));
{for(var i = 0, len = gdjs.lettersCode.GDdbgObjects2.length ;i < len;++i) {
    gdjs.lettersCode.GDdbgObjects2[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(4)));
}
}}

}


{


gdjs.lettersCode.condition0IsTrue_0.val = false;
gdjs.lettersCode.condition1IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.lettersCode.condition0IsTrue_0.val ) {
{
{gdjs.lettersCode.conditionTrue_1 = gdjs.lettersCode.condition1IsTrue_0;
gdjs.lettersCode.conditionTrue_1.val = context.triggerOnce(240515420);
}
}}
if (gdjs.lettersCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf7540(runtimeScene, context);} //End of subevents
}

}


{


gdjs.lettersCode.condition0IsTrue_0.val = false;
gdjs.lettersCode.condition1IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
}if ( gdjs.lettersCode.condition0IsTrue_0.val ) {
{
{gdjs.lettersCode.conditionTrue_1 = gdjs.lettersCode.condition1IsTrue_0;
gdjs.lettersCode.conditionTrue_1.val = context.triggerOnce(240515708);
}
}}
if (gdjs.lettersCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf6640(runtimeScene, context);} //End of subevents
}

}


}; //End of gdjs.lettersCode.eventsList0x1caf7a20
gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersLenObjects4Objects = Hashtable.newFrom({"lettersLen": gdjs.lettersCode.GDlettersLenObjects4});gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSenObjects4Objects = Hashtable.newFrom({"lettersSen": gdjs.lettersCode.GDlettersSenObjects4});gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersLenObjects4Objects = Hashtable.newFrom({"lettersLen": gdjs.lettersCode.GDlettersLenObjects4});gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSenObjects4Objects = Hashtable.newFrom({"lettersSen": gdjs.lettersCode.GDlettersSenObjects4});gdjs.lettersCode.eventsList0xe5cb158 = function(runtimeScene, context) {

{

gdjs.lettersCode.GDlettersLenObjects4.createFrom(gdjs.lettersCode.GDlettersLenObjects3);

gdjs.lettersCode.GDlettersSenObjects4.createFrom(runtimeScene.getObjects("lettersSen"));

gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersLenObjects4Objects, gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSenObjects4Objects, true, runtimeScene);
}if (gdjs.lettersCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).setNumber(0);
}}

}


{

gdjs.lettersCode.GDlettersLenObjects4.createFrom(gdjs.lettersCode.GDlettersLenObjects3);

gdjs.lettersCode.GDlettersSenObjects4.createFrom(runtimeScene.getObjects("lettersSen"));

gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersLenObjects4Objects, gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSenObjects4Objects, false, runtimeScene);
}if (gdjs.lettersCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).setNumber(1);
}}

}


}; //End of gdjs.lettersCode.eventsList0xe5cb158
gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSenObjects1Objects = Hashtable.newFrom({"lettersSen": gdjs.lettersCode.GDlettersSenObjects1});gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersLenObjects1Objects = Hashtable.newFrom({"lettersLen": gdjs.lettersCode.GDlettersLenObjects1});gdjs.lettersCode.eventsList0x1caf7780 = function(runtimeScene, context) {

{


{
}

}


}; //End of gdjs.lettersCode.eventsList0x1caf7780
gdjs.lettersCode.eventsList0x1caf74e0 = function(runtimeScene, context) {

{


{
/* Reuse gdjs.lettersCode.GDlettersSenObjects1 */
gdjs.lettersCode.GDlettersLenObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersLenObjects1Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), "");
}{for(var i = 0, len = gdjs.lettersCode.GDlettersLenObjects1.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersLenObjects1[i].setZOrder(5);
}
}{for(var i = 0, len = gdjs.lettersCode.GDlettersLenObjects1.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersLenObjects1[i].activateBehavior("Draggable", true);
}
}{for(var i = 0, len = gdjs.lettersCode.GDlettersLenObjects1.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersLenObjects1[i].setAnimation((( gdjs.lettersCode.GDlettersSenObjects1.length === 0 ) ? 0 :gdjs.lettersCode.GDlettersSenObjects1[0].getAnimation()));
}
}{for(var i = 0, len = gdjs.lettersCode.GDlettersLenObjects1.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersLenObjects1[i].setScale(2);
}
}{for(var i = 0, len = gdjs.lettersCode.GDlettersLenObjects1.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersLenObjects1[i].setColor("255;255;80");
}
}
{ //Subevents
gdjs.lettersCode.eventsList0x1caf7780(runtimeScene, context);} //End of subevents
}

}


}; //End of gdjs.lettersCode.eventsList0x1caf74e0
gdjs.lettersCode.eventsList0x1caf71e0 = function(runtimeScene, context) {

{

gdjs.lettersCode.GDlettersSenObjects1.createFrom(runtimeScene.getObjects("lettersSen"));

gdjs.lettersCode.condition0IsTrue_0.val = false;
gdjs.lettersCode.condition1IsTrue_0.val = false;
gdjs.lettersCode.condition2IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSenObjects1Objects, runtimeScene, true, false);
}if ( gdjs.lettersCode.condition0IsTrue_0.val ) {
{
gdjs.lettersCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.lettersCode.condition1IsTrue_0.val ) {
{
{gdjs.lettersCode.conditionTrue_1 = gdjs.lettersCode.condition2IsTrue_0;
gdjs.lettersCode.conditionTrue_1.val = context.triggerOnce(240516788);
}
}}
}
if (gdjs.lettersCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf74e0(runtimeScene, context);} //End of subevents
}

}


}; //End of gdjs.lettersCode.eventsList0x1caf71e0
gdjs.lettersCode.eventsList0x1caf69a0 = function(runtimeScene, context) {

{


{
}

}


{

gdjs.lettersCode.GDlettersLenObjects2.createFrom(runtimeScene.getObjects("lettersLen"));

for(gdjs.lettersCode.forEachIndex3 = 0;gdjs.lettersCode.forEachIndex3 < gdjs.lettersCode.GDlettersLenObjects2.length;++gdjs.lettersCode.forEachIndex3) {
gdjs.lettersCode.GDlettersLenObjects3.createFrom(gdjs.lettersCode.GDlettersLenObjects2);


gdjs.lettersCode.forEachTemporary3 = gdjs.lettersCode.GDlettersLenObjects2[gdjs.lettersCode.forEachIndex3];
gdjs.lettersCode.GDlettersLenObjects3.length = 0;
gdjs.lettersCode.GDlettersLenObjects3.push(gdjs.lettersCode.forEachTemporary3);
if (true) {

{ //Subevents: 
gdjs.lettersCode.eventsList0xe5cb158(runtimeScene, context);} //Subevents end.
}
}

}


{



}


{



}


{


gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) == 0;
}if (gdjs.lettersCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf71e0(runtimeScene, context);} //End of subevents
}

}


}; //End of gdjs.lettersCode.eventsList0x1caf69a0
gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersLgrObjects4Objects = Hashtable.newFrom({"lettersLgr": gdjs.lettersCode.GDlettersLgrObjects4});gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSgrObjects4Objects = Hashtable.newFrom({"lettersSgr": gdjs.lettersCode.GDlettersSgrObjects4});gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersLgrObjects4Objects = Hashtable.newFrom({"lettersLgr": gdjs.lettersCode.GDlettersLgrObjects4});gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSgrObjects4Objects = Hashtable.newFrom({"lettersSgr": gdjs.lettersCode.GDlettersSgrObjects4});gdjs.lettersCode.eventsList0xe5cb0e8 = function(runtimeScene, context) {

{

gdjs.lettersCode.GDlettersLgrObjects4.createFrom(gdjs.lettersCode.GDlettersLgrObjects3);

gdjs.lettersCode.GDlettersSgrObjects4.createFrom(runtimeScene.getObjects("lettersSgr"));

gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersLgrObjects4Objects, gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSgrObjects4Objects, true, runtimeScene);
}if (gdjs.lettersCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).setNumber(0);
}}

}


{

gdjs.lettersCode.GDlettersLgrObjects4.createFrom(gdjs.lettersCode.GDlettersLgrObjects3);

gdjs.lettersCode.GDlettersSgrObjects4.createFrom(runtimeScene.getObjects("lettersSgr"));

gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersLgrObjects4Objects, gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSgrObjects4Objects, false, runtimeScene);
}if (gdjs.lettersCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).setNumber(1);
}}

}


}; //End of gdjs.lettersCode.eventsList0xe5cb0e8
gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSgrObjects1Objects = Hashtable.newFrom({"lettersSgr": gdjs.lettersCode.GDlettersSgrObjects1});gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersLgrObjects1Objects = Hashtable.newFrom({"lettersLgr": gdjs.lettersCode.GDlettersLgrObjects1});gdjs.lettersCode.eventsList0x1caf7420 = function(runtimeScene, context) {

{


{
}

}


}; //End of gdjs.lettersCode.eventsList0x1caf7420
gdjs.lettersCode.eventsList0x1caf6580 = function(runtimeScene, context) {

{


{
/* Reuse gdjs.lettersCode.GDlettersSgrObjects1 */
gdjs.lettersCode.GDlettersLgrObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersLgrObjects1Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), "");
}{for(var i = 0, len = gdjs.lettersCode.GDlettersLgrObjects1.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersLgrObjects1[i].setZOrder(5);
}
}{for(var i = 0, len = gdjs.lettersCode.GDlettersLgrObjects1.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersLgrObjects1[i].activateBehavior("Draggable", true);
}
}{for(var i = 0, len = gdjs.lettersCode.GDlettersLgrObjects1.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersLgrObjects1[i].setAnimation((( gdjs.lettersCode.GDlettersSgrObjects1.length === 0 ) ? 0 :gdjs.lettersCode.GDlettersSgrObjects1[0].getAnimation()));
}
}{for(var i = 0, len = gdjs.lettersCode.GDlettersLgrObjects1.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersLgrObjects1[i].setScale(2);
}
}{for(var i = 0, len = gdjs.lettersCode.GDlettersLgrObjects1.length ;i < len;++i) {
    gdjs.lettersCode.GDlettersLgrObjects1[i].setColor("255;255;80");
}
}
{ //Subevents
gdjs.lettersCode.eventsList0x1caf7420(runtimeScene, context);} //End of subevents
}

}


}; //End of gdjs.lettersCode.eventsList0x1caf6580
gdjs.lettersCode.eventsList0x1caf6a00 = function(runtimeScene, context) {

{

gdjs.lettersCode.GDlettersSgrObjects1.createFrom(runtimeScene.getObjects("lettersSgr"));

gdjs.lettersCode.condition0IsTrue_0.val = false;
gdjs.lettersCode.condition1IsTrue_0.val = false;
gdjs.lettersCode.condition2IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDlettersSgrObjects1Objects, runtimeScene, true, false);
}if ( gdjs.lettersCode.condition0IsTrue_0.val ) {
{
gdjs.lettersCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.lettersCode.condition1IsTrue_0.val ) {
{
{gdjs.lettersCode.conditionTrue_1 = gdjs.lettersCode.condition2IsTrue_0;
gdjs.lettersCode.conditionTrue_1.val = context.triggerOnce(240518012);
}
}}
}
if (gdjs.lettersCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf6580(runtimeScene, context);} //End of subevents
}

}


}; //End of gdjs.lettersCode.eventsList0x1caf6a00
gdjs.lettersCode.eventsList0x1caf6940 = function(runtimeScene, context) {

{


{
}

}


{

gdjs.lettersCode.GDlettersLgrObjects2.createFrom(runtimeScene.getObjects("lettersLgr"));

for(gdjs.lettersCode.forEachIndex3 = 0;gdjs.lettersCode.forEachIndex3 < gdjs.lettersCode.GDlettersLgrObjects2.length;++gdjs.lettersCode.forEachIndex3) {
gdjs.lettersCode.GDlettersLgrObjects3.createFrom(gdjs.lettersCode.GDlettersLgrObjects2);


gdjs.lettersCode.forEachTemporary3 = gdjs.lettersCode.GDlettersLgrObjects2[gdjs.lettersCode.forEachIndex3];
gdjs.lettersCode.GDlettersLgrObjects3.length = 0;
gdjs.lettersCode.GDlettersLgrObjects3.push(gdjs.lettersCode.forEachTemporary3);
if (true) {

{ //Subevents: 
gdjs.lettersCode.eventsList0xe5cb0e8(runtimeScene, context);} //Subevents end.
}
}

}


{


gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) == 0;
}if (gdjs.lettersCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf6a00(runtimeScene, context);} //End of subevents
}

}


}; //End of gdjs.lettersCode.eventsList0x1caf6940
gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDenbObjects1Objects = Hashtable.newFrom({"enb": gdjs.lettersCode.GDenbObjects1});gdjs.lettersCode.eventsList0x1caf6a60 = function(runtimeScene, context) {

{


{
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("EN");
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "letters", false);
}}

}


}; //End of gdjs.lettersCode.eventsList0x1caf6a60
gdjs.lettersCode.eventsList0x1caf1fc0 = function(runtimeScene, context) {

{


gdjs.lettersCode.condition0IsTrue_0.val = false;
{
{gdjs.lettersCode.conditionTrue_1 = gdjs.lettersCode.condition0IsTrue_0;
gdjs.lettersCode.conditionTrue_1.val = context.triggerOnce(240518732);
}
}if (gdjs.lettersCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(4).setNumber(0);
}}

}


{


{
{runtimeScene.getVariables().getFromIndex(4).add(1 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}}

}


{


gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) >= 2;
}if (gdjs.lettersCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf6a60(runtimeScene, context);} //End of subevents
}

}


}; //End of gdjs.lettersCode.eventsList0x1caf1fc0
gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDgrbObjects1Objects = Hashtable.newFrom({"grb": gdjs.lettersCode.GDgrbObjects1});gdjs.lettersCode.eventsList0x1caf3c40 = function(runtimeScene, context) {

{


{
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("GR");
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "letters", false);
}}

}


}; //End of gdjs.lettersCode.eventsList0x1caf3c40
gdjs.lettersCode.eventsList0x1caf3ca0 = function(runtimeScene, context) {

{


gdjs.lettersCode.condition0IsTrue_0.val = false;
{
{gdjs.lettersCode.conditionTrue_1 = gdjs.lettersCode.condition0IsTrue_0;
gdjs.lettersCode.conditionTrue_1.val = context.triggerOnce(240519380);
}
}if (gdjs.lettersCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(4).setNumber(0);
}}

}


{


{
{runtimeScene.getVariables().getFromIndex(4).add(1 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}}

}


{


gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) >= 2;
}if (gdjs.lettersCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf3c40(runtimeScene, context);} //End of subevents
}

}


}; //End of gdjs.lettersCode.eventsList0x1caf3ca0
gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDerbObjects1Objects = Hashtable.newFrom({"erb": gdjs.lettersCode.GDerbObjects1});gdjs.lettersCode.eventsList0x1caf42a0 = function(runtimeScene, context) {

{


{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "letters", false);
}}

}


}; //End of gdjs.lettersCode.eventsList0x1caf42a0
gdjs.lettersCode.eventsList0x1caf4de0 = function(runtimeScene, context) {

{


gdjs.lettersCode.condition0IsTrue_0.val = false;
{
{gdjs.lettersCode.conditionTrue_1 = gdjs.lettersCode.condition0IsTrue_0;
gdjs.lettersCode.conditionTrue_1.val = context.triggerOnce(240519956);
}
}if (gdjs.lettersCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(4).setNumber(0);
}}

}


{


{
{runtimeScene.getVariables().getFromIndex(4).add(1 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}}

}


{


gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) >= 2;
}if (gdjs.lettersCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf42a0(runtimeScene, context);} //End of subevents
}

}


}; //End of gdjs.lettersCode.eventsList0x1caf4de0
gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDenbObjects2ObjectsGDgdjs_46lettersCode_46GDgrbObjects2ObjectsGDgdjs_46lettersCode_46GDerbObjects2Objects = Hashtable.newFrom({"enb": gdjs.lettersCode.GDenbObjects2, "grb": gdjs.lettersCode.GDgrbObjects2, "erb": gdjs.lettersCode.GDerbObjects2});gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDenbObjects1ObjectsGDgdjs_46lettersCode_46GDgrbObjects1ObjectsGDgdjs_46lettersCode_46GDerbObjects1Objects = Hashtable.newFrom({"enb": gdjs.lettersCode.GDenbObjects1, "grb": gdjs.lettersCode.GDgrbObjects1, "erb": gdjs.lettersCode.GDerbObjects1});gdjs.lettersCode.eventsList0x1caf56e0 = function(runtimeScene, context) {

{

gdjs.lettersCode.GDenbObjects2.createFrom(runtimeScene.getObjects("enb"));
gdjs.lettersCode.GDerbObjects2.createFrom(runtimeScene.getObjects("erb"));
gdjs.lettersCode.GDgrbObjects2.createFrom(runtimeScene.getObjects("grb"));

gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDenbObjects2ObjectsGDgdjs_46lettersCode_46GDgrbObjects2ObjectsGDgdjs_46lettersCode_46GDerbObjects2Objects, runtimeScene, true, false);
}if (gdjs.lettersCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lettersCode.GDenbObjects2 */
/* Reuse gdjs.lettersCode.GDerbObjects2 */
/* Reuse gdjs.lettersCode.GDgrbObjects2 */
{for(var i = 0, len = gdjs.lettersCode.GDenbObjects2.length ;i < len;++i) {
    gdjs.lettersCode.GDenbObjects2[i].setColor("255;255;128");
}
for(var i = 0, len = gdjs.lettersCode.GDgrbObjects2.length ;i < len;++i) {
    gdjs.lettersCode.GDgrbObjects2[i].setColor("255;255;128");
}
for(var i = 0, len = gdjs.lettersCode.GDerbObjects2.length ;i < len;++i) {
    gdjs.lettersCode.GDerbObjects2[i].setColor("255;255;128");
}
}}

}


{

gdjs.lettersCode.GDenbObjects1.createFrom(runtimeScene.getObjects("enb"));
gdjs.lettersCode.GDerbObjects1.createFrom(runtimeScene.getObjects("erb"));
gdjs.lettersCode.GDgrbObjects1.createFrom(runtimeScene.getObjects("grb"));

gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDenbObjects1ObjectsGDgdjs_46lettersCode_46GDgrbObjects1ObjectsGDgdjs_46lettersCode_46GDerbObjects1Objects, runtimeScene, true, true);
}if (gdjs.lettersCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lettersCode.GDenbObjects1 */
/* Reuse gdjs.lettersCode.GDerbObjects1 */
/* Reuse gdjs.lettersCode.GDgrbObjects1 */
{for(var i = 0, len = gdjs.lettersCode.GDenbObjects1.length ;i < len;++i) {
    gdjs.lettersCode.GDenbObjects1[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.lettersCode.GDgrbObjects1.length ;i < len;++i) {
    gdjs.lettersCode.GDgrbObjects1[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.lettersCode.GDerbObjects1.length ;i < len;++i) {
    gdjs.lettersCode.GDerbObjects1[i].setColor("255;255;255");
}
}}

}


}; //End of gdjs.lettersCode.eventsList0x1caf56e0
gdjs.lettersCode.eventsList0x28e238 = function(runtimeScene, context) {

{


gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.lettersCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf73c0(runtimeScene, context);} //End of subevents
}

}


{


gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}if (gdjs.lettersCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf7a20(runtimeScene, context);} //End of subevents
}

}


{


gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "EN";
}if (gdjs.lettersCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf69a0(runtimeScene, context);} //End of subevents
}

}


{


gdjs.lettersCode.condition0IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "GR";
}if (gdjs.lettersCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf6940(runtimeScene, context);} //End of subevents
}

}


{

gdjs.lettersCode.GDenbObjects1.createFrom(runtimeScene.getObjects("enb"));

gdjs.lettersCode.condition0IsTrue_0.val = false;
gdjs.lettersCode.condition1IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDenbObjects1Objects, runtimeScene, true, false);
}if ( gdjs.lettersCode.condition0IsTrue_0.val ) {
{
gdjs.lettersCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.lettersCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf1fc0(runtimeScene, context);} //End of subevents
}

}


{

gdjs.lettersCode.GDgrbObjects1.createFrom(runtimeScene.getObjects("grb"));

gdjs.lettersCode.condition0IsTrue_0.val = false;
gdjs.lettersCode.condition1IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDgrbObjects1Objects, runtimeScene, true, false);
}if ( gdjs.lettersCode.condition0IsTrue_0.val ) {
{
gdjs.lettersCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.lettersCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf3ca0(runtimeScene, context);} //End of subevents
}

}


{

gdjs.lettersCode.GDerbObjects1.createFrom(runtimeScene.getObjects("erb"));

gdjs.lettersCode.condition0IsTrue_0.val = false;
gdjs.lettersCode.condition1IsTrue_0.val = false;
{
gdjs.lettersCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lettersCode.mapOfGDgdjs_46lettersCode_46GDerbObjects1Objects, runtimeScene, true, false);
}if ( gdjs.lettersCode.condition0IsTrue_0.val ) {
{
gdjs.lettersCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.lettersCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.lettersCode.eventsList0x1caf4de0(runtimeScene, context);} //End of subevents
}

}


{


{

{ //Subevents
gdjs.lettersCode.eventsList0x1caf56e0(runtimeScene, context);} //End of subevents
}

}


}; //End of gdjs.lettersCode.eventsList0x28e238


gdjs.lettersCode.func = function(runtimeScene, context) {
context.startNewFrame();
gdjs.lettersCode.GDbgObjects1.length = 0;
gdjs.lettersCode.GDbgObjects2.length = 0;
gdjs.lettersCode.GDbgObjects3.length = 0;
gdjs.lettersCode.GDbgObjects4.length = 0;
gdjs.lettersCode.GDbgObjects5.length = 0;
gdjs.lettersCode.GDbgObjects6.length = 0;
gdjs.lettersCode.GDlettersLenObjects1.length = 0;
gdjs.lettersCode.GDlettersLenObjects2.length = 0;
gdjs.lettersCode.GDlettersLenObjects3.length = 0;
gdjs.lettersCode.GDlettersLenObjects4.length = 0;
gdjs.lettersCode.GDlettersLenObjects5.length = 0;
gdjs.lettersCode.GDlettersLenObjects6.length = 0;
gdjs.lettersCode.GDlettersSenObjects1.length = 0;
gdjs.lettersCode.GDlettersSenObjects2.length = 0;
gdjs.lettersCode.GDlettersSenObjects3.length = 0;
gdjs.lettersCode.GDlettersSenObjects4.length = 0;
gdjs.lettersCode.GDlettersSenObjects5.length = 0;
gdjs.lettersCode.GDlettersSenObjects6.length = 0;
gdjs.lettersCode.GDlettersLgrObjects1.length = 0;
gdjs.lettersCode.GDlettersLgrObjects2.length = 0;
gdjs.lettersCode.GDlettersLgrObjects3.length = 0;
gdjs.lettersCode.GDlettersLgrObjects4.length = 0;
gdjs.lettersCode.GDlettersLgrObjects5.length = 0;
gdjs.lettersCode.GDlettersLgrObjects6.length = 0;
gdjs.lettersCode.GDlettersSgrObjects1.length = 0;
gdjs.lettersCode.GDlettersSgrObjects2.length = 0;
gdjs.lettersCode.GDlettersSgrObjects3.length = 0;
gdjs.lettersCode.GDlettersSgrObjects4.length = 0;
gdjs.lettersCode.GDlettersSgrObjects5.length = 0;
gdjs.lettersCode.GDlettersSgrObjects6.length = 0;
gdjs.lettersCode.GDdbgObjects1.length = 0;
gdjs.lettersCode.GDdbgObjects2.length = 0;
gdjs.lettersCode.GDdbgObjects3.length = 0;
gdjs.lettersCode.GDdbgObjects4.length = 0;
gdjs.lettersCode.GDdbgObjects5.length = 0;
gdjs.lettersCode.GDdbgObjects6.length = 0;
gdjs.lettersCode.GDenbObjects1.length = 0;
gdjs.lettersCode.GDenbObjects2.length = 0;
gdjs.lettersCode.GDenbObjects3.length = 0;
gdjs.lettersCode.GDenbObjects4.length = 0;
gdjs.lettersCode.GDenbObjects5.length = 0;
gdjs.lettersCode.GDenbObjects6.length = 0;
gdjs.lettersCode.GDgrbObjects1.length = 0;
gdjs.lettersCode.GDgrbObjects2.length = 0;
gdjs.lettersCode.GDgrbObjects3.length = 0;
gdjs.lettersCode.GDgrbObjects4.length = 0;
gdjs.lettersCode.GDgrbObjects5.length = 0;
gdjs.lettersCode.GDgrbObjects6.length = 0;
gdjs.lettersCode.GDerbObjects1.length = 0;
gdjs.lettersCode.GDerbObjects2.length = 0;
gdjs.lettersCode.GDerbObjects3.length = 0;
gdjs.lettersCode.GDerbObjects4.length = 0;
gdjs.lettersCode.GDerbObjects5.length = 0;
gdjs.lettersCode.GDerbObjects6.length = 0;

gdjs.lettersCode.eventsList0x28e238(runtimeScene, context);return;
}
gdjs['lettersCode']= gdjs.lettersCode;
